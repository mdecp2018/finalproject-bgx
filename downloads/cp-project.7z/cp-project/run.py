from PyQt5 import QtWidgets
from ui import main

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ui = main.Form()
    ui.show()
    sys.exit(app.exec())
